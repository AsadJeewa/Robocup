package gui.applications.soccer_field;

import aima.core.agent.impl.AbstractAgent;
import aima.gui.framework.AgentAppController;
import aima.gui.framework.AgentAppFrame;
import aima.gui.framework.MessageLogger;
import aima.gui.framework.SimulationThread;
import environment.soccer_field.GoalKeeperAgent;
import environment.soccer_field.SoccerFieldEnvironment;

public class SoccerController extends AgentAppController {

	protected SoccerFieldEnvironment env = null;
	protected GoalKeeperAgent agent = null;
	protected boolean isPrepared = false;
	protected boolean isRunning = false;
	private int numRounds = 1;
	private SoccerView view;

	@Override
	public void clear() {
		if (!isPrepared())
			prepare(null);
	}

	@Override
	public void prepare(String changedSelector) {
		AgentAppFrame.SelectionState selState = frame.getSelection();
		numRounds = selState.getValue(SoccerFrame.ROUND_SEL) + 1;

		env = new SoccerFieldEnvironment(15,1);
		agent = new GoalKeeperAgent();

		frame.getEnvView().setEnvironment(env);
		env.addAgent(agent);
		
		isPrepared = true;
		view = (SoccerView)frame.getEnvView();
		view.setRenderable(false);
	}

	@Override
	public boolean isPrepared() {
		return isPrepared && !env.isDone();
	}

	/** Starts simulation. */
	@Override
	public void run(MessageLogger logger) {
		for(int i = 0; i < numRounds;i++){
			logger.log("<simulation-log>");
			isRunning = true;
			env = new SoccerFieldEnvironment();
			agent = new GoalKeeperAgent();
			if(i == 0)
				agent.randInit();

			frame.getEnvView().setEnvironment(env);
			env.addAgent(agent);
			
			isPrepared = true;
			view = (SoccerView)frame.getEnvView();
			view.setRenderable(true);
			try {
				while (!env.isDone() ) {
					Thread.sleep(500);
					if(!frame.simulationPaused())
						env.step();
					view.repaint();
				}
			} catch (InterruptedException e) {
			}
			logger.log("</simulation-log>\n");
			isRunning = false;
		}
		
	}

	/** Executes one simulation step. */
	@Override
	public void step(MessageLogger logger) {
	}

	/** Updates the status of the frame after simulation has finished. */
	public void update(SimulationThread simulationThread) {
		if (simulationThread.isCanceled()) {
			frame.setStatus("Task canceled.");
			isPrepared = false;
		} else if (frame.simulationPaused()) {
			frame.setStatus("Task paused.");
		} else {
			frame.setStatus("Task completed.");
		}
	}
}
