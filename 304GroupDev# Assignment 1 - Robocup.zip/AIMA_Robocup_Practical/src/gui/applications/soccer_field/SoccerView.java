package gui.applications.soccer_field;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.Hashtable;

import javax.swing.ImageIcon;

import aima.core.agent.Action;
import aima.core.agent.Agent;
import aima.core.agent.EnvironmentState;
import aima.gui.framework.EmptyEnvironmentView;
import environment.soccer_field.SoccerFieldEnvironment;

public class SoccerView extends EmptyEnvironmentView {
	
	private static final long serialVersionUID = 1L;
	private Hashtable<Agent, Action> lastActions = new Hashtable<Agent, Action>();
	private SoccerFieldEnvironment sfenv;
	private int scaleFactor = 10;
	
	private ImageIcon fieldImage = new ImageIcon("images/field.jpg");
	private ImageIcon playerImage = new ImageIcon("images/smiley1.png");
	private ImageIcon ballImage = new ImageIcon("images/sball.png");
	private ImageIcon goalKeeperImage = new ImageIcon("images/smiley.png");
	
	boolean render = false;
	
	
	
	@Override
	public void agentActed(Agent agent, Action action, EnvironmentState resultingState) {
		// lastActions.put(agent, action);
		// String prefix = "";
		// if (env.getAgents().size() > 1)
		// prefix = "A" + env.getAgents().indexOf(agent) + ": ";
		// notify(prefix + action.toString());
		// super.agentActed(agent, action, resultingState);\
	}

	protected SoccerFieldEnvironment getSoccerFieldEnv() {
		return (SoccerFieldEnvironment) env;
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if(render){
			
			sfenv = (SoccerFieldEnvironment)env;
			Image imgField = fieldImage.getImage();
			Image imgBall = ballImage.getImage();
			Image imgGK = goalKeeperImage.getImage();
			Image imgPlayer = playerImage.getImage();
		
			g.setColor(Color.ORANGE);
			g.fillRect(0,0,SoccerFieldEnvironment.FIELD_LENGTH*scaleFactor, 
					SoccerFieldEnvironment.FIELD_WIDTH*scaleFactor);
			g.drawImage(imgField, 0, 0, SoccerFieldEnvironment.FIELD_LENGTH*scaleFactor, 
					SoccerFieldEnvironment.FIELD_WIDTH*scaleFactor, null);
			
			
			g.setColor(Color.WHITE);
			g.fillRect(scaleFactor, (SoccerFieldEnvironment.FIELD_WIDTH*scaleFactor / 2) - SoccerFieldEnvironment.GOAL_LENGTH*scaleFactor/2, 5, SoccerFieldEnvironment.GOAL_LENGTH*scaleFactor);
		
			g.drawImage(imgBall, (int) Math.round(sfenv.getState().getBallX()*scaleFactor) - scaleFactor,
					(int) Math.round(sfenv.getState().getBallY()*scaleFactor) - scaleFactor, scaleFactor*2, scaleFactor*2, null);
		
			g.setColor(Color.BLUE);
			g.drawImage(imgGK, (int) Math.round(sfenv.getGoalKeeper().x*scaleFactor) - scaleFactor,
					(int) Math.round(sfenv.getGoalKeeper().y*scaleFactor) - scaleFactor, scaleFactor*2, scaleFactor*2, null);
			
			g.drawImage(imgPlayer, (15 * scaleFactor)-scaleFactor,
					(int) Math.round(sfenv.FIELD_WIDTH/2)*scaleFactor - scaleFactor, scaleFactor*2, scaleFactor*2, null);
		
			}
		
	}
	
	public void setRenderable(boolean b){
		render = b;
	}
}
