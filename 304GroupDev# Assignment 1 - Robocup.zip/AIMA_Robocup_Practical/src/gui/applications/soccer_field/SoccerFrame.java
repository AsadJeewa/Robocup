package gui.applications.soccer_field;

import aima.gui.framework.AgentAppFrame;

public class SoccerFrame extends AgentAppFrame {
	private static final long serialVersionUID = 1L;
	public static String ROUND_SEL = "RoundSelection";

	public SoccerFrame() {
		super();
		setTitle("Soccer Agent Application");
		setSelectors(new String[] { ROUND_SEL }, new String[] { "Select Number of Rounds" });
		setSelectorItems(ROUND_SEL, new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }, 0);
		setEnvView(new SoccerView());
		setSize(1450, 600);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public SoccerView getView(){
		return (SoccerView)this.getEnvView();
	}
	
	@Override
	public void updateEnabledState(){
		super.updateEnabledState();
		stepButton.setEnabled(false);
	}
}
