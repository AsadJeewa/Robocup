package gui.applications.soccer_field;

import aima.gui.framework.AgentAppController;
import aima.gui.framework.AgentAppEnvironmentView;
import aima.gui.framework.AgentAppFrame;
import aima.gui.framework.SimpleAgentApp;

public class SoccerApp extends SimpleAgentApp {

	@Override
	public AgentAppEnvironmentView createEnvironmentView() {
		return new SoccerView();
	}

	@Override
	public AgentAppFrame createFrame() {
		return new SoccerFrame();
	}

	@Override
	public AgentAppController createController() {
		return new SoccerController();
	}

	public static void main(String args[]) {
		new SoccerApp().startApplication();
	}
	
	
}
