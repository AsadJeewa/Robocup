package environment.soccer_field;


import aima.core.agent.Agent;
import aima.core.agent.EnvironmentState;

public class SoccerFieldEnvironmentState implements EnvironmentState, FullyObservableSoccerFieldEnvironmentPercept{

	private SoccerBall ball;
	
	public SoccerFieldEnvironmentState(double angle, double velocity){
		ball = new SoccerBall(velocity, angle);
	}

	public void setAgentLocation(Agent a, int direction){
		if(a instanceof GoalKeeperAgent){
			GoalKeeperAgent gk = (GoalKeeperAgent)a;
			gk.move(direction);
		}
	}
	
	public void updateEnvironmentState(){
		ball.move();
	}
	

	@Override
	public String getBallLocation() {
		String location = ball.getXPosition()+":"+ball.getYPosition();
		return location;
	}

	public double getBallX(){
		return ball.getXPosition();
	}
	
	public double getBallY(){
		return ball.getYPosition();
	}

	@Override
	public String getAgentLocation(Agent a) {
		return null;
	}
}
