package environment.soccer_field;

import aima.core.agent.Action;
import aima.core.agent.AgentProgram;
import aima.core.agent.Percept;
import aima.core.agent.impl.AbstractAgent;

public class GoalKeeperAgent extends AbstractAgent {
	// private ImageIcon img = new ImageIcon("src/res/smiley.png");
	// private float xPosition = 0;
	// private float yPosition = 250;
	// private float speed = 1;//amount of units GK moves evrty time repaint is
	// called

	static boolean pathToGoal = false;
	static boolean firstSight = true;
	public static double x = 1;
	public static double y = 25;
	static double goalX = 0;
	static double goalY = 0;

	public GoalKeeperAgent() {
		super(new AgentProgram() {
			public Action execute(Percept percept) {
				LocalGoalKeeperEnvironmentPercept gkep = (LocalGoalKeeperEnvironmentPercept) percept;
				// double ballX = gkep.getAttribute("ballLocation");
				if(firstSight){
					firstSight=false;
					return SoccerFieldEnvironment.ACTION_STAY;
				}
				if (!pathToGoal && firstSight == false) {
					String ballLocation = gkep.getBallLocation();
					double ballX = Double.parseDouble(ballLocation.substring(0,
							ballLocation.indexOf(":")));
					double ballY = Double.parseDouble(ballLocation
							.substring(ballLocation.indexOf(":") + 1));
					
					double angle = Math.toDegrees((Math.atan2(ballY-25, ballX-15)));
					double deltaY = 15*Math.tan(Math.toRadians(angle));
					goalY = Math.round(25-deltaY);
					pathToGoal = true;
					System.out.println("Agent perceives: ");
					System.out.println("Ball angle: " + (angle) + " degrees");
					System.out.println("Path to save goal found");
					System.out.println(Math.abs(goalY - y)+" step(s) to Point of Intersection");
				}

				//System.out.println(y+" y pos");
				//System.out.println(goalY+ "goal pos");
				if(y == goalY) return SoccerFieldEnvironment.ACTION_SAVE;
				if(y < goalY)
					return SoccerFieldEnvironment.ACTION_MOVE_LEFT;
				else if(y > goalY)
					return SoccerFieldEnvironment.ACTION_MOVE_RIGHT;
				else return SoccerFieldEnvironment.ACTION_STAY;
			}
		});
		pathToGoal = false;
		firstSight = true;
	}
	
	public void move(int direction){
		y+= direction == 0 ? -1 : 1;
	}
	
	public void randInit(){
		y = (int)(Math.random()*(SoccerFieldEnvironment.GOAL_LENGTH + 1)+ SoccerFieldEnvironment.FIELD_WIDTH/2
				- SoccerFieldEnvironment.GOAL_LENGTH/2);
	}

}
