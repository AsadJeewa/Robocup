package environment.soccer_field;

import aima.core.agent.impl.DynamicPercept;

public class LocalGoalKeeperEnvironmentPercept extends DynamicPercept{

	public static final String ATTRIBUTE_BALL_LOCATION = "ballLocation";
	
	public LocalGoalKeeperEnvironmentPercept(String ballLocation) {
		setAttribute(ATTRIBUTE_BALL_LOCATION, ballLocation);
	}
	
	public String getBallLocation(){
		return (String) getAttribute(ATTRIBUTE_BALL_LOCATION);
	}
	
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		sb.append(getBallLocation());
		sb.append("]");
		return sb.toString();
	}
	
}
