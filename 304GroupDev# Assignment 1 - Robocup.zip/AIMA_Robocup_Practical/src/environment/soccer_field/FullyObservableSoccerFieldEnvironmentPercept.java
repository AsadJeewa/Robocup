package environment.soccer_field;

import aima.core.agent.Agent;
import aima.core.agent.Percept;

public interface FullyObservableSoccerFieldEnvironmentPercept extends Percept{
		
	String getAgentLocation(Agent a);
	String getBallLocation();
}
