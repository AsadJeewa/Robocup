package environment.soccer_field;


import aima.core.agent.Action;
import aima.core.agent.Agent;
import aima.core.agent.EnvironmentState;
import aima.core.agent.Percept;
import aima.core.agent.impl.AbstractEnvironment;
import aima.core.agent.impl.DynamicAction;

public class SoccerFieldEnvironment extends AbstractEnvironment{
	
	public static final Action ACTION_MOVE_LEFT = new DynamicAction("Left");
	public static final Action ACTION_MOVE_RIGHT = new DynamicAction("Right");
	public static final Action ACTION_STAY = new DynamicAction("Stay");
	public static final Action ACTION_SAVE = new DynamicAction("Save");
	
	public enum State{
		Goal, InPlay
	};
	
	protected SoccerFieldEnvironmentState envState = null;
	protected boolean isDone = false;
	
	public static final int FIELD_LENGTH = 100;
	public static final int FIELD_WIDTH = 50;
	public static final int GOAL_LENGTH = 15;
	//private int gap = 20;

	public SoccerFieldEnvironment() {
		double angle = ((int)(Math.random()*(26565+26565+1)-26565))/1000;
		int opt = (int)(Math.random()*(7));
		double velocity = getVelocity(opt);
		envState = new SoccerFieldEnvironmentState(angle, velocity);
		isDone = false;
	}
	
	public SoccerFieldEnvironment(double angle, double velocity){
		envState = new SoccerFieldEnvironmentState(angle, velocity);
	}

	private double getVelocity(int opt){
		switch(opt){
		case 0: return 0.25;
		case 1: return 0.5;
		case 2: return 0.75;
		case 3: return 1;
		case 4: return 1.25;
		case 5: return 1.75;
		case 6: return 2;
		}
		return 1;
	}

	@Override
	public EnvironmentState executeAction(Agent agent, Action agentAction) {
		//Move the agent
		if(agentAction == ACTION_MOVE_RIGHT){
			envState.setAgentLocation(agent, 0);
		}
		else if(agentAction == ACTION_MOVE_LEFT)
			envState.setAgentLocation(agent, 1);
		else if(agentAction == ACTION_SAVE)
			isDone = true;
		//move the ball
		envState.updateEnvironmentState();
		return envState;
	}

	@Override
	public EnvironmentState getCurrentState() {
		return envState;
	}

	public SoccerFieldEnvironmentState getState(){
		return envState;
	}
	
	@Override
	public Percept getPerceptSeenBy(Agent agent) {
		String ballLocation = envState.getBallLocation();
		return new LocalGoalKeeperEnvironmentPercept(ballLocation);
	}
	
	@Override
	public boolean isDone(){
		if(isDone){
			System.out.println("Save!");
			return isDone;
		}
		double x = envState.getBallX();
		if( x <= 0){
			isDone = true;
			System.out.println("Goal!");
		}
		return isDone;
	}
	
	public GoalKeeperAgent getGoalKeeper(){
		return (GoalKeeperAgent)getAgents().get(0);
	}
}
