package environment.soccer_field;


public class SoccerBall {
	private double xPosition = 0;
	private double yPosition = 0;
	private double angle = 20;// 26.565<=angle<-25.565 to never shoot wide
	private double speed = 0;//amount of units GK moves evrty time repaint is called
	

	public SoccerBall(double speed, double angle) {
		xPosition = 15;//temp values
		yPosition = 25;
		this.speed = speed;
		this.angle = angle+180;
	}

	public double getAngle() {
		return angle;
	}

	public void setAngle(float angle) {
		this.angle = angle;
	}

	public double getXPosition() {
		return xPosition;
	}

	public double getYPosition() {
		return yPosition;
	}

	public void setCoords(double x, double y) {
		xPosition = x;
		yPosition = y;
	}
	
	public void move(){
		double newX = xPosition + speed*(Math.cos(Math.toRadians(angle)));
		double newY = yPosition - speed*(Math.sin(Math.toRadians(angle)));
		
		setCoords(newX, newY);
	}
}

